function thongbao() {
    document.getElementById("hi").innerHTML = "Hello J";
}